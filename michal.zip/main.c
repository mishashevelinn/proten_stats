#include <stdio.h>
#include <malloc.h>
#include "ProtStats.h"

int main() {
//    printf("%d\n",num_prots("example1.fasta"));
//    ProtStats* protptr1;
//    ProtStats* protptr2;
//
//    protptr1=ProtStatsCreate("prot1","MEIVCNQNEFNYAIQLVSKAVASRPTHPILANLLLTADQGT");
//    printf("%s ,%d\n",protptr1->name,protptr1->length);
//
//    protptr2=ProtStatsCreate("prot2","MCGIVGIVSCDDVNQQ");
//    printf("%s ,%d\n",protptr2->name,protptr2->length);
//
//    ProtStatsInit("prot1","MEIVCNQNEFNYAIQLVSKAVASRPTHPILANLLLTADQGT",protptr1);
//    printf("%f, %f, %f\n", protptr1->aa_freq[H],protptr1->aa_freq[P],protptr1->aa_freq[C] );
//
//    ProtStatsInit("prot2","MCGIVGIVSCDDVNQQ",protptr2);
//
//    ProtStatSwap(protptr1,protptr2);
//    printf("%s, %d, %f, %f, %f\n", protptr1->name,protptr1->length,
//           protptr1->aa_freq[H],protptr1->aa_freq[C],protptr1->aa_freq[P]);
//    printf("%s, %d, %f, %f, %f\n", protptr2->name,protptr2->length,
//           protptr2->aa_freq[H],protptr2->aa_freq[C],protptr2->aa_freq[P]);
//


    /**Initializing an array of pointers to structs ProtStats**/
    unsigned int len = 0;
    ProtStats** protArray;
    protArray=read_fasta_file("example1.fasta",&len);

  /** קראנו בהצלחה את המידע מהקובץ לשדות של STRUCT
     כעת נדפיס את השמות של חלבונים      *****/
    printf("%s",protArray[0]->name);
    printf("%s", protArray[1]->name);

    /**עכשיו ננסה להעתיק את סטראקט השני לראשון. השם של השני הועתק
     * בהצחה לשדה של הראשון תוך שימוש בהשמה של פוניטרים: SHALLOW COPY
     * כעת השדות NAME של שני הסטראקטים מצביעים על אותו אזור בזיכרון*/
    ProtStatCopy(protArray[0], protArray[1]);
    printf("%s", protArray[0]->name);


    /**מה ירקרה אם נמחק את השם של הסראקט הראשון? האם זה ישפיע על השני? האם אנחנו מעוניים בהשפעה כזאת?
     * רמז: DEEP COPY
     * נרצה לבצע העתקה העמוקה של שדה NAME, בעזרת פונקציית ספריה STRDUP
     * שמקבלת מצביע לCHAR ומחזירה מצביע להיתק באזור אחר בזכרון עם תוכן זדהה לתוכן של הארגומנט
     * יש לשים לב כי STRDUP מבצעת הקצאת זכרון דינמית. לכן חובה לדוודא שהתוכן המועתק נמחק
     * בעת סיום שימוש בהעתק*/
    free(protArray[0]->name);
    printf("%s", protArray[1]->name);



    return 0;
}
